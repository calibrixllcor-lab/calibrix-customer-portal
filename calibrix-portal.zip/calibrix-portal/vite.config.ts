import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  // Relative base so the app works on GitHub Pages / any sub-path host.
  // Hash-based routing means no server rewrites are required.
  base: './',
});
