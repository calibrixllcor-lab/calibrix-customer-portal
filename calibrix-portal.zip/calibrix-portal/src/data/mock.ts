import type { User, WIP_Record } from '../types';

// Global mutable store (mock database).
// Replace these with API calls when wiring up a real backend.
export const MOCK_USERS: User[] = [
  { id: 'u1', email: 'admin@calibrixllc.com', name: 'System Admin', role: 'ADMIN' },
  { id: 'u3', email: 'shop@collisioncenter.com', name: 'Yovani', role: 'CUSTOMER', phone: '503-330-7097', shopName: 'Hillsboro Collision' },
];

export const MOCK_WIP: WIP_Record[] = [
  { id: 'w1', roNumber: 'RO-9921', vin: '1HGCM82633A', make: 'Honda', model: 'Accord', year: 2021, insurance: 'State Farm', estimator: 'Dan G.', id3Rec: 'S', serviceType: 'Static ADAS Services', status: 'Scheduled', submittedDate: '2026-09-08', requestedDate: '2026-09-10', assignedDate: '2026-09-10' },
  { id: 'w2', roNumber: 'RO-9945', vin: '2T1BURHE31C', make: 'Toyota', model: 'Camry', year: 2022, insurance: 'GEICO', estimator: 'Sarah L.', id3Rec: 'V', serviceType: 'Dynamic ADAS Services', status: 'Unscheduled', submittedDate: '2026-09-09', requestedDate: '2026-09-12' },
  { id: 'w3', roNumber: 'RO-9950', vin: '5YJ3E1EA5JF', make: 'Tesla', model: 'Model 3', year: 2023, insurance: 'Progressive', estimator: 'Dan G.', id3Rec: 'FIR', serviceType: 'EV Services', status: 'Complete', submittedDate: '2026-09-01', requestedDate: '2026-09-05', assignedDate: '2026-09-05', completedDate: '2026-09-05' },
];
