export const Button = ({ children, onClick, variant = 'primary', className = '', type = 'button', disabled = false }: any) => {
  const base = 'px-4 py-2 rounded-lg font-medium transition-colors duration-200 flex items-center justify-center gap-2';
  const variants = {
    primary: 'bg-[#22c55e] text-black hover:bg-[#16a34a] shadow-sm',
    secondary: 'bg-neutral-800 text-neutral-200 hover:bg-neutral-700 border border-neutral-700',
    danger: 'bg-red-500 text-white hover:bg-red-600 shadow-sm',
    ghost: 'bg-transparent text-neutral-400 hover:bg-neutral-800 hover:text-white',
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`${base} ${variants[variant as keyof typeof variants]} ${className} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      {children}
    </button>
  );
};

export const Card = ({ children, className = '' }: any) => (
  <div className={`bg-[#171717] border border-neutral-800 rounded-xl shadow-lg overflow-hidden ${className}`}>
    {children}
  </div>
);

export const Input = ({ label, type = 'text', ...props }: any) => (
  <div className="flex flex-col gap-1.5 w-full">
    {label && <label className="text-sm font-medium text-neutral-300">{label}</label>}
    <input
      type={type}
      className="px-3 py-2 border border-neutral-700 rounded-lg bg-[#0a0a0a] text-neutral-100 focus:ring-1 focus:ring-[#22c55e] focus:border-[#22c55e] outline-none transition-all"
      {...props}
    />
  </div>
);

export const Select = ({ label, options, ...props }: any) => (
  <div className="flex flex-col gap-1.5 w-full">
    {label && <label className="text-sm font-medium text-neutral-300">{label}</label>}
    <select
      className="px-3 py-2 border border-neutral-700 rounded-lg bg-[#0a0a0a] text-neutral-100 focus:ring-1 focus:ring-[#22c55e] focus:border-[#22c55e] outline-none transition-all"
      {...props}
    >
      <option value="">Select...</option>
      {options.map((opt: string) => (
        <option key={opt} value={opt}>
          {opt}
        </option>
      ))}
    </select>
  </div>
);

export const Id3Badge = ({ rec }: { rec: string }) => {
  const colors: Record<string, string> = {
    S: 'bg-blue-500/20 text-blue-400 border-blue-500/50',
    V: 'bg-purple-500/20 text-purple-400 border-purple-500/50',
    NCR: 'bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]/50',
    No: 'bg-neutral-500/20 text-neutral-400 border-neutral-500/50',
    FIR: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50',
  };
  return (
    <span className={`px-2 py-1 rounded text-xs font-bold border ${colors[rec] || colors.No}`} title="ID3 Recommendation">
      {rec}
    </span>
  );
};
