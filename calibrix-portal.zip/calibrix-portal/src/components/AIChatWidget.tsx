import React, { useState, useEffect, useRef } from 'react';
import { Bot, MessageSquare, Sparkles, Send, Minimize2 } from 'lucide-react';
import { Button, Card } from './ui';
import { fetchGeminiChat, systemPromptAdvisor } from '../lib/gemini';

const AIChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; text: string }[]>([
    { role: 'model', text: 'Hi! I am the Calibrix AI Assistant. How can I help you today?' },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messagesEndRef.current) messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isOpen]);

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isLoading) return;
    const userMsg = input.trim();
    setInput('');
    setMessages((prev) => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);
    const apiHistory = messages
      .concat({ role: 'user', text: userMsg })
      .map((m) => ({ role: m.role, parts: [{ text: m.text }] }));
    const responseText = await fetchGeminiChat(apiHistory, systemPromptAdvisor);
    setMessages((prev) => [...prev, { role: 'model', text: responseText }]);
    setIsLoading(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {isOpen && (
        <Card className="w-80 sm:w-96 h-[500px] mb-4 flex flex-col shadow-2xl border border-[#22c55e]/30">
          <div className="bg-[#0a0a0a] border-b border-neutral-800 p-4 flex justify-between items-center">
            <div className="flex items-center gap-2 text-[#22c55e]">
              <Bot className="h-5 w-5" />
              <span className="font-semibold text-white">Calibrix AI</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-neutral-400 hover:text-white transition-colors">
              <Minimize2 className="h-5 w-5" />
            </button>
          </div>
          <div className="flex-1 p-4 overflow-y-auto bg-[#171717] flex flex-col gap-3">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-2 text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-[#22c55e] text-black rounded-br-none font-medium'
                      : 'bg-neutral-800 text-neutral-200 rounded-bl-none shadow-sm'
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="max-w-[80%] rounded-2xl px-4 py-3 bg-neutral-800 rounded-bl-none shadow-sm flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#22c55e] rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-[#22c55e] rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                  <div className="w-2 h-2 bg-[#22c55e] rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          <div className="p-3 bg-[#0a0a0a] border-t border-neutral-800">
            <form onSubmit={handleSend} className="flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 bg-neutral-800 border-transparent focus:bg-neutral-900 focus:border-[#22c55e] focus:ring-1 focus:ring-[#22c55e] rounded-lg px-3 py-2 text-sm outline-none transition-all text-white"
              />
              <Button type="submit" variant="primary" className="!p-2 rounded-lg" disabled={isLoading || !input.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </Card>
      )}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-[#22c55e] hover:bg-[#16a34a] text-black p-4 rounded-full shadow-lg shadow-[#22c55e]/20 transition-transform hover:scale-105 active:scale-95 flex items-center justify-center group"
        >
          <MessageSquare className="h-6 w-6 group-hover:hidden" />
          <Sparkles className="h-6 w-6 hidden group-hover:block animate-pulse" />
        </button>
      )}
    </div>
  );
};

export default AIChatWidget;
