export type Role = 'CUSTOMER' | 'ADMIN';

export interface User {
  id: string;
  email: string;
  name: string;
  role: Role;
  phone?: string;
  shopName?: string;
}

export interface WIP_Record {
  id: string;
  roNumber: string;
  vin: string;
  make: string;
  model: string;
  year: number;
  insurance: string;
  estimator: string;
  id3Rec: 'S' | 'V' | 'NCR' | 'No' | 'FIR';
  serviceType: string;
  status: 'Unscheduled' | 'Scheduled' | 'Complete';
  submittedDate: string;
  requestedDate: string;
  assignedDate?: string;
  completedDate?: string;
}
