import { useState } from 'react';
import { CreditCard, HelpCircle, Settings } from 'lucide-react';

import type { Role, User } from './types';
import { MOCK_USERS } from './data/mock';
import { AuthContext } from './context/AuthContext';
import { useHashRouter } from './hooks/useHashRouter';

import PublicLayout from './layouts/PublicLayout';
import PortalLayout from './layouts/PortalLayout';
import HomePage from './pages/HomePage';
import AuthPage from './pages/AuthPage';
import CustomerWorkRequestForm from './pages/CustomerWorkRequestForm';
import AdminWorkInProgress from './pages/admin/AdminWorkInProgress';
import AdminManageRequests from './pages/admin/AdminManageRequests';
import AdminADASRecs from './pages/admin/AdminADASRecs';
import AdminPlaceholder from './pages/admin/AdminPlaceholder';
import AdminSystemArch from './pages/admin/AdminSystemArch';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const { path, navigate } = useHashRouter();

  const login = (email: string, role: Role = 'CUSTOMER') => {
    // Check if user exists in mock DB
    let user = MOCK_USERS.find((u) => u.email === email);
    if (!user) {
      // Create temporary session user if logging in directly from demo without registering
      user = { id: Date.now().toString(), email, name: email.split('@')[0], role, shopName: role === 'CUSTOMER' ? 'Hillsboro Collision' : '' };
    }
    setCurrentUser(user);
  };

  const register = (userData: Partial<User>) => {
    const newUser: User = {
      id: Date.now().toString(),
      email: userData.email || '',
      name: userData.name || 'New User',
      role: (userData.role as Role) || 'CUSTOMER',
      phone: userData.phone,
      shopName: userData.shopName,
    };
    MOCK_USERS.push(newUser); // Add to mock DB
    setCurrentUser(newUser); // Auto login
  };

  const logout = () => setCurrentUser(null);

  const renderContent = () => {
    // 1. PUBLIC ROUTES
    if (!currentUser) {
      if (path === '/login') return <AuthPage login={login} register={register} navigate={navigate} initialMode="login" />;
      if (path === '/register') return <AuthPage login={login} register={register} navigate={navigate} initialMode="register" />;
      return <HomePage navigate={navigate} />;
    }

    // 2. PORTAL ROUTES
    if (path.startsWith('/portal')) {
      return (
        <PortalLayout user={currentUser} logout={logout} navigate={navigate} path={path}>
          {/* CUSTOMER VIEWS */}
          {path === '/portal' && currentUser.role === 'CUSTOMER' && <CustomerWorkRequestForm />}

          {/* ADMIN VIEWS (The Detailed Dashboard) */}
          {path === '/portal' && currentUser.role === 'ADMIN' && <AdminWorkInProgress navigate={navigate} />}
          {path === '/portal/requests' && currentUser.role === 'ADMIN' && <AdminManageRequests />}
          {path === '/portal/adas-recs' && currentUser.role === 'ADMIN' && <AdminADASRecs />}
          {path === '/portal/invoiced' && currentUser.role === 'ADMIN' && <AdminPlaceholder title="Invoiced" desc="Access all invoices for completed requests." icon={CreditCard} />}
          {path === '/portal/support' && currentUser.role === 'ADMIN' && <AdminPlaceholder title="Support" desc="Log a support request or view history." icon={HelpCircle} />}
          {path === '/portal/shop' && currentUser.role === 'ADMIN' && <AdminPlaceholder title="Manage Shop" desc="Shop settings, WIP auto-close, and user invites." icon={Settings} />}
          {path === '/portal/system' && currentUser.role === 'ADMIN' && <AdminSystemArch />}
        </PortalLayout>
      );
    }

    // Default redirect to portal if logged in but on public route
    if (path === '/' || path === '/login' || path === '/register') {
      setTimeout(() => navigate('/portal'), 0);
      return null;
    }

    return <HomePage navigate={navigate} />;
  };

  return (
    <AuthContext.Provider value={{ user: currentUser, login, register, logout }}>
      <div className="min-h-screen bg-[#0a0a0a] text-neutral-100 font-sans selection:bg-[#22c55e]/30 selection:text-white flex flex-col">
        {!currentUser && !path.startsWith('/portal') ? (
          <PublicLayout navigate={navigate}>{renderContent()}</PublicLayout>
        ) : (
          renderContent()
        )}
      </div>
    </AuthContext.Provider>
  );
}
