import { Button } from '../components/ui';

const HomePage = ({ navigate }: any) => (
  <div className="flex-1 flex flex-col items-center justify-center">
    <div className="w-full py-24 px-4 text-center relative overflow-hidden flex-1 flex flex-col justify-center">
      {/* Background Accents */}
      <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none flex justify-center items-center">
        <div className="w-[800px] h-[800px] border-[1px] border-[#22c55e] rounded-full absolute -top-1/4 -right-1/4"></div>
        <div className="w-[600px] h-[600px] border-[1px] border-[#22c55e] rounded-full absolute bottom-0 left-[-20%]"></div>
      </div>

      <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6 max-w-4xl mx-auto text-white">
        Precision <span className="text-[#22c55e]">ADAS Calibration</span>.
      </h1>
      <p className="text-lg md:text-xl text-neutral-400 max-w-2xl mx-auto mb-10">
        Enterprise-grade camera, radar, and sensor calibration. Streamlining your collision center workflows.
      </p>
      <div className="flex flex-col sm:flex-row gap-4 justify-center relative z-10">
        <Button onClick={() => navigate('/login')} className="h-14 px-10 text-lg font-bold tracking-wide rounded-full">
          Submit Work Request
        </Button>
      </div>
    </div>
  </div>
);

export default HomePage;
