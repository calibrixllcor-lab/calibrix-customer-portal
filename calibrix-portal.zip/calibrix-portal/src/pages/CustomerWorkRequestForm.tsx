import { useState } from 'react';
import { CheckCircle } from 'lucide-react';
import { Button, Card, Input, Select } from '../components/ui';

const CustomerWorkRequestForm = () => {
  const [numVehicles, setNumVehicles] = useState(1);
  const [submitted, setSubmitted] = useState(false);

  const serviceOptions = [
    'A/C Services',
    'Diagnostic Service',
    'Dynamic ADAS Services',
    'Estimate Only',
    'EV Services',
    'Mechanical Services',
    'On Board ADAS Services',
    'Remote Diagnostic Scan',
    'Static ADAS Services',
  ];

  if (submitted) {
    return (
      <Card className="max-w-2xl mx-auto p-12 text-center border-[#22c55e]/30 mt-10 bg-[#171717]">
        <CheckCircle className="h-16 w-16 text-[#22c55e] mx-auto mb-6" />
        <h2 className="text-2xl font-bold text-white mb-4">Request Submitted Successfully</h2>
        <p className="text-neutral-400 mb-8">Thank you for contacting us. A Calibrix representative will contact you shortly to schedule your service.</p>
        <Button onClick={() => setSubmitted(false)} variant="secondary" className="mx-auto">Submit Another Request</Button>
      </Card>
    );
  }

  return (
    <div className="max-w-4xl mx-auto pb-12">
      <div className="mb-8 border-b border-neutral-800 pb-6">
        <h1 className="text-3xl font-bold text-white mb-2 uppercase tracking-wide">Work Request Form</h1>
        <p className="text-neutral-400">Submit this form and our dispatch team will contact you to schedule the right virtual, mobile or other service for you.</p>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }} className="space-y-8">
        {/* Contact Information */}
        <Card className="p-6 md:p-8 border-neutral-800">
          <div className="flex items-center gap-3 mb-6">
            <div className="h-8 w-8 rounded-full bg-[#22c55e] text-black flex items-center justify-center font-bold">1</div>
            <h2 className="text-xl font-bold text-white">Contact Information</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="Contact Name" required />
            <Input label="Phone Number" type="tel" required />
            <Input label="Email Address" type="email" required />
            <Input label="Shop/Center Name (Optional)" />
            <Input label="Center Number (Optional)" />
            <div className="md:col-span-2">
              <Input label="Street Address" required />
            </div>
            <Input label="City, State" required />
            <Input label="Zip Code" required />
          </div>
        </Card>

        {/* Vehicle Information */}
        <Card className="p-6 md:p-8 border-neutral-800">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-full bg-[#22c55e] text-black flex items-center justify-center font-bold">2</div>
              <h2 className="text-xl font-bold text-white">Vehicle Information</h2>
            </div>
            <div className="flex items-center gap-3 bg-[#0a0a0a] p-2 rounded-lg border border-neutral-800">
              <label className="text-sm font-medium text-neutral-400 pl-2">Number of Vehicles (max 5):</label>
              <select
                value={numVehicles}
                onChange={(e) => setNumVehicles(Number(e.target.value))}
                className="bg-[#171717] border border-neutral-700 text-white text-sm rounded px-3 py-1.5 outline-none focus:border-[#22c55e]"
              >
                {[1, 2, 3, 4, 5].map((n) => (
                  <option key={n} value={n}>{n}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-8">
            {Array.from({ length: numVehicles }).map((_, index) => (
              <div key={index} className="p-6 bg-[#0a0a0a] rounded-lg border border-neutral-800 relative">
                {numVehicles > 1 && (
                  <div className="absolute top-0 right-0 bg-[#22c55e] text-black text-xs px-3 py-1 rounded-bl-lg rounded-tr-lg font-bold">
                    VEHICLE {index + 1}
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-5 mt-2">
                  <Input label="Vehicle Year" placeholder="YYYY" required />
                  <Input label="Vehicle Make" placeholder="e.g. Honda" required />
                  <Input label="Vehicle Model" placeholder="e.g. Accord" required />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
                  <Input label="Vehicle VIN" placeholder="17-Digit VIN" required />
                  <Input label="Repair Order Number" required />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
                  <Select
                    label="Insurance Carrier"
                    options={['State Farm', 'GEICO', 'Progressive', 'Allstate', 'USAA', 'Liberty Mutual', 'Farmers', 'Other']}
                    required
                  />
                  <Select label="Requested Service" options={serviceOptions} required />
                </div>

                <div>
                  <label className="text-sm font-medium text-neutral-300 mb-1.5 block">
                    Work Request Notes <span className="text-neutral-500 text-xs font-normal">(Please be as descriptive as possible)</span>
                  </label>
                  <textarea
                    className="w-full px-3 py-3 border border-neutral-700 rounded-lg bg-[#171717] text-neutral-100 focus:ring-1 focus:ring-[#22c55e] outline-none transition-all min-h-[100px] resize-y"
                    placeholder="Describe the requested work (e.g., ADAS Static Calibration after windshield replacement...)"
                    required
                  ></textarea>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <div className="flex justify-end pt-4">
          <Button type="submit" className="h-12 px-8 text-lg font-bold">Submit Work Request</Button>
        </div>
      </form>
    </div>
  );
};

export default CustomerWorkRequestForm;
