import { Search } from 'lucide-react';
import { Card, Id3Badge } from '../../components/ui';
import { MOCK_WIP } from '../../data/mock';

const AdminWorkInProgress = ({ navigate }: any) => {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 border-b border-neutral-800 pb-6">
        <div>
          <h1 className="text-2xl font-bold text-white mb-1">Work In Progress</h1>
          <p className="text-neutral-400 text-sm">Manage active ROs and ID3 Recommendations globally.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-5 flex flex-col justify-center h-32 border-neutral-800 bg-[#171717]">
          <p className="text-sm font-medium text-neutral-400 mb-2">WIP by Insurance</p>
          <div className="flex gap-4 items-end h-16">
            <div className="w-12 bg-blue-500 rounded-t flex items-end justify-center pb-1 text-xs font-bold text-white shadow-[0_0_10px_rgba(59,130,246,0.3)]" style={{ height: '80%' }} title="State Farm">4</div>
            <div className="w-12 bg-[#22c55e] rounded-t flex items-end justify-center pb-1 text-xs font-bold text-black shadow-[0_0_10px_rgba(34,197,94,0.3)]" style={{ height: '40%' }} title="GEICO">2</div>
            <div className="w-12 bg-purple-500 rounded-t flex items-end justify-center pb-1 text-xs font-bold text-white shadow-[0_0_10px_rgba(168,85,247,0.3)]" style={{ height: '60%' }} title="Progressive">3</div>
          </div>
        </Card>
        <Card className="p-5 border-neutral-800 bg-[#171717]">
          <p className="text-sm font-medium text-neutral-400 mb-3">ID3 Recommended Services</p>
          <div className="flex flex-wrap gap-2">
            <button className="px-3 py-1.5 text-xs font-bold rounded bg-blue-500/20 text-blue-400 border border-blue-500/50 hover:bg-blue-500/30">S (Scan)</button>
            <button className="px-3 py-1.5 text-xs font-bold rounded bg-purple-500/20 text-purple-400 border border-purple-500/50 hover:bg-purple-500/30">V (VIN)</button>
            <button className="px-3 py-1.5 text-xs font-bold rounded bg-[#22c55e]/20 text-[#22c55e] border border-[#22c55e]/50 hover:bg-[#22c55e]/30">NCR</button>
            <button className="px-3 py-1.5 text-xs font-bold rounded bg-neutral-500/20 text-neutral-400 border border-neutral-500/50 hover:bg-neutral-500/30">No</button>
            <button className="px-3 py-1.5 text-xs font-bold rounded bg-yellow-500/20 text-yellow-400 border border-yellow-500/50 hover:bg-yellow-500/30">FIR</button>
            <button className="px-3 py-1.5 text-xs font-bold rounded bg-transparent text-neutral-500 border border-neutral-700 hover:text-white">Clear</button>
          </div>
        </Card>
      </div>

      <Card className="overflow-x-auto border-neutral-800">
        <div className="p-4 border-b border-neutral-800 flex justify-between items-center bg-[#0a0a0a]">
          <h3 className="font-semibold text-white">Active WIP List</h3>
          <div className="flex gap-2">
            <div className="relative">
              <Search className="h-4 w-4 absolute left-3 top-2.5 text-neutral-500" />
              <input type="text" placeholder="Search RO..." className="pl-9 pr-3 py-1.5 bg-[#171717] border border-neutral-700 rounded-lg text-sm text-white focus:border-[#22c55e] outline-none" />
            </div>
          </div>
        </div>
        <table className="w-full text-left text-sm">
          <thead className="bg-[#171717] border-b border-neutral-800 text-neutral-400">
            <tr>
              <th className="px-4 py-3 font-medium">RO Number</th>
              <th className="px-4 py-3 font-medium">Vehicle / VIN</th>
              <th className="px-4 py-3 font-medium">Insurance</th>
              <th className="px-4 py-3 font-medium">ID3 Rec</th>
              <th className="px-4 py-3 font-medium">Promised Date</th>
              <th className="px-4 py-3 font-medium">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-800 bg-[#0a0a0a]">
            {MOCK_WIP.filter((w) => w.status !== 'Complete').map((wip) => (
              <tr key={wip.id} className="hover:bg-neutral-900 transition-colors">
                <td className="px-4 py-3 font-mono text-white">{wip.roNumber}</td>
                <td className="px-4 py-3">
                  <div className="font-medium text-white">{wip.year} {wip.make} {wip.model}</div>
                  <div className="text-xs text-neutral-500 font-mono">{wip.vin}</div>
                </td>
                <td className="px-4 py-3 text-neutral-300">{wip.insurance}</td>
                <td className="px-4 py-3"><Id3Badge rec={wip.id3Rec} /></td>
                <td className="px-4 py-3 text-neutral-300">{wip.requestedDate}</td>
                <td className="px-4 py-3">
                  <button className="text-[#22c55e] hover:text-[#16a34a] text-xs font-semibold uppercase tracking-wider">Manage</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
};

export default AdminWorkInProgress;
