import { Card } from '../../components/ui';

const AdminPlaceholder = ({ title, desc, icon: Icon }: any) => (
  <div className="space-y-6">
    <div className="border-b border-neutral-800 pb-6">
      <h1 className="text-2xl font-bold text-white mb-1">{title}</h1>
      <p className="text-neutral-400 text-sm">{desc}</p>
    </div>
    <Card className="flex flex-col items-center justify-center p-16 text-neutral-500 border-dashed border-2 border-neutral-800 bg-[#0a0a0a]/50">
      <Icon className="h-12 w-12 mb-4 opacity-30 text-[#22c55e]" />
      <p>This module is currently connected to the primary CRM.</p>
    </Card>
  </div>
);

export default AdminPlaceholder;
