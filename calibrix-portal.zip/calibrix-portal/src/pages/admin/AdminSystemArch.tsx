import { Card } from '../../components/ui';

const AdminSystemArch = () => (
  <div className="space-y-6">
    <div className="mb-6 border-b border-neutral-800 pb-6">
      <h1 className="text-2xl font-bold text-white mb-1">System Architecture (Dev)</h1>
      <p className="text-neutral-400 text-sm">Configuration exports for Cloudflare Next.js deployment.</p>
    </div>

    <div className="grid gap-6">
      <Card className="p-0 overflow-hidden border-neutral-800">
        <div className="bg-[#0a0a0a] text-neutral-300 px-4 py-3 text-sm font-mono border-b border-neutral-800 flex justify-between items-center">
          <span>schema.sql</span>
          <span className="text-xs bg-[#22c55e]/10 text-[#22c55e] px-2 py-0.5 rounded font-bold border border-[#22c55e]/30">Cloudflare D1</span>
        </div>
        <pre className="p-4 bg-[#171717] text-neutral-300 text-sm overflow-x-auto whitespace-pre-wrap">
{`CREATE TABLE Users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  role TEXT CHECK(role IN ('CUSTOMER', 'ADMIN')),
  shop_name TEXT
);

CREATE TABLE WIP_Records (
  id TEXT PRIMARY KEY,
  ro_number TEXT NOT NULL,
  vin TEXT NOT NULL,
  id3_rec TEXT,
  service_type TEXT,
  status TEXT DEFAULT 'Unscheduled',
  submitted_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  assigned_date DATETIME
);`}
        </pre>
      </Card>

      <Card className="p-0 overflow-hidden border-neutral-800">
        <div className="bg-[#0a0a0a] text-neutral-300 px-4 py-3 text-sm font-mono border-b border-neutral-800 flex justify-between items-center">
          <span>wrangler.toml</span>
          <span className="text-xs bg-[#22c55e]/10 text-[#22c55e] px-2 py-0.5 rounded font-bold border border-[#22c55e]/30">Pages Config</span>
        </div>
        <pre className="p-4 bg-[#171717] text-neutral-300 text-sm overflow-x-auto whitespace-pre-wrap">
{`name = "calibrix-portal"
compatibility_date = "2024-01-01"
pages_build_output_dir = ".vercel/output/static"

[[d1_databases]]
binding = "DB"
database_name = "calibrix-db-prod"
database_id = "xxxx-xxxx-xxxx"
migrations_dir = "migrations"`}
        </pre>
      </Card>

      <Card className="p-0 overflow-hidden border-neutral-800">
        <div className="bg-[#0a0a0a] text-neutral-300 px-4 py-3 text-sm font-mono border-b border-neutral-800 flex justify-between items-center">
          <span>package.json</span>
          <span className="text-xs bg-blue-500/10 text-blue-400 px-2 py-0.5 rounded font-bold border border-blue-500/30">Node</span>
        </div>
        <pre className="p-4 bg-[#171717] text-neutral-300 text-sm overflow-x-auto whitespace-pre-wrap">
{`{
  "name": "calibrix-production",
  "version": "1.0.0",
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  },
  "dependencies": {
    "next": "^14.1.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "lucide-react": "^0.344.0"
  },
  "devDependencies": {
    "typescript": "^5.3.3",
    "tailwindcss": "^3.4.1",
    "@cloudflare/workers-types": "^4.20240222.0"
  }
}`}
        </pre>
      </Card>
    </div>
  </div>
);

export default AdminSystemArch;
