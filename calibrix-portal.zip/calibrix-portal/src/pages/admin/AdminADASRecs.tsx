import { AlertCircle, Calculator } from 'lucide-react';
import { Button, Card, Input } from '../../components/ui';

const AdminADASRecs = () => (
  <div className="space-y-6">
    <div className="border-b border-neutral-800 pb-6">
      <h1 className="text-2xl font-bold text-white mb-1">ADAS Recommendations</h1>
      <p className="text-neutral-400 text-sm">Review ID3 opportunities and calculate potential profit margins.</p>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card className="p-6 md:col-span-2">
        <div className="flex justify-between items-center mb-6">
          <h3 className="font-bold text-white">Recommendation List</h3>
          <select className="bg-[#0a0a0a] border border-neutral-700 text-white text-sm rounded px-3 py-1 outline-none">
            <option>Work In Progress</option>
            <option>Opportunities</option>
            <option>Closed</option>
          </select>
        </div>
        <div className="text-center text-neutral-500 py-12 border-2 border-dashed border-neutral-800 rounded-lg bg-[#0a0a0a]/50">
          <AlertCircle className="h-8 w-8 mx-auto mb-3 opacity-50 text-[#22c55e]" />
          <p>No new opportunities identified in current WIP.</p>
        </div>
      </Card>

      <Card className="p-6 bg-[#171717] border-[#22c55e]/30 shadow-[0_0_15px_rgba(34,197,94,0.05)]">
        <div className="flex items-center gap-2 mb-4">
          <Calculator className="h-5 w-5 text-[#22c55e]" />
          <h3 className="font-bold text-white">ADAS Calculator</h3>
        </div>
        <div className="space-y-4">
          <Input label="Avg Rev Invoice Amount ($)" type="number" defaultValue="450" />
          <Input label="Margin (%)" type="number" defaultValue="25" />
          <div className="pt-4 border-t border-neutral-800 mt-4">
            <p className="text-sm text-neutral-400 mb-1">Potential Profit per Rec</p>
            <p className="text-3xl font-extrabold text-[#22c55e]">$112.50</p>
          </div>
          <Button className="w-full mt-4">Recalculate</Button>
        </div>
      </Card>
    </div>
  </div>
);

export default AdminADASRecs;
