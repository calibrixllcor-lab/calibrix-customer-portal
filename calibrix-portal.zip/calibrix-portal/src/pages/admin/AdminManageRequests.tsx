import { Card } from '../../components/ui';
import { MOCK_WIP } from '../../data/mock';

const AdminManageRequests = () => (
  <div className="space-y-6">
    <div className="flex justify-between items-end border-b border-neutral-800 pb-6">
      <div>
        <h1 className="text-2xl font-bold text-white mb-1">Manage Requests</h1>
        <p className="text-neutral-400 text-sm">View the status of all submitted service requests.</p>
      </div>
    </div>

    <Card className="overflow-x-auto border-neutral-800 bg-[#171717]">
      <div className="p-4 border-b border-neutral-800 flex justify-between items-center">
        <h3 className="font-semibold text-white">All Service Requests</h3>
      </div>
      <table className="w-full text-left text-sm">
        <thead className="bg-[#0a0a0a] border-b border-neutral-800 text-neutral-400">
          <tr>
            <th className="px-4 py-3 font-medium">Submitted</th>
            <th className="px-4 py-3 font-medium">Requested Date</th>
            <th className="px-4 py-3 font-medium">Assigned</th>
            <th className="px-4 py-3 font-medium">RO #</th>
            <th className="px-4 py-3 font-medium">Service Type</th>
            <th className="px-4 py-3 font-medium">Status</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-neutral-800 bg-[#171717]">
          {MOCK_WIP.map((req) => (
            <tr key={req.id} className="hover:bg-neutral-900">
              <td className="px-4 py-3 text-neutral-300">{req.submittedDate}</td>
              <td className="px-4 py-3 text-neutral-300">{req.requestedDate}</td>
              <td className="px-4 py-3 text-neutral-300">{req.assignedDate || '-'}</td>
              <td className="px-4 py-3 font-mono text-white">{req.roNumber}</td>
              <td className="px-4 py-3 text-neutral-300">{req.serviceType}</td>
              <td className="px-4 py-3">
                <span
                  className={`px-2 py-1 rounded text-xs font-bold border ${
                    req.status === 'Complete'
                      ? 'bg-[#22c55e]/20 text-[#22c55e] border-[#22c55e]/50'
                      : req.status === 'Scheduled'
                      ? 'bg-blue-500/20 text-blue-400 border-blue-500/50'
                      : 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50'
                  }`}
                >
                  {req.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </Card>
  </div>
);

export default AdminManageRequests;
