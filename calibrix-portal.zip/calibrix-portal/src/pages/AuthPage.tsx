import React, { useState } from 'react';
import { LogIn, UserPlus } from 'lucide-react';
import { Button, Card, Input } from '../components/ui';
import type { Role } from '../types';

const AuthPage = ({ login, register, navigate, initialMode = 'login' }: any) => {
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);

  // Login State
  const [loginEmail, setLoginEmail] = useState('');
  const [roleDemo, setRoleDemo] = useState<Role>('CUSTOMER');

  // Register State
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regShop, setRegShop] = useState('');

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login(loginEmail || 'demo@calibrix.com', roleDemo);
    navigate('/portal');
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, send to API. Here, we mock registration and auto-login.
    register({
      name: regName,
      email: regEmail,
      phone: regPhone,
      shopName: regShop,
      role: 'CUSTOMER', // New signups default to Customer
    });
    navigate('/portal');
  };

  return (
    <div className="flex-1 flex items-center justify-center px-4 py-12">
      <Card className="w-full max-w-md p-8 shadow-2xl border-[#22c55e]/20 bg-[#171717]/90 backdrop-blur-sm">
        <div className="text-center mb-8">
          <div className="h-14 w-14 rounded bg-[#22c55e] text-black font-extrabold flex items-center justify-center mx-auto mb-4 text-3xl">C</div>
          <h2 className="text-2xl font-bold tracking-widest text-white">CALIBRIX</h2>
          <p className="text-neutral-400 mt-2 text-sm">{mode === 'login' ? 'Portal Access' : 'Create an Account'}</p>
        </div>

        {/* Form Toggle */}
        <div className="flex bg-[#0a0a0a] rounded-lg p-1 mb-8 border border-neutral-800">
          <button
            className={`flex-1 py-2 text-sm font-bold rounded-md transition-colors ${mode === 'login' ? 'bg-neutral-800 text-white shadow' : 'text-neutral-400 hover:text-white'}`}
            onClick={() => setMode('login')}
          >
            Sign In
          </button>
          <button
            className={`flex-1 py-2 text-sm font-bold rounded-md transition-colors ${mode === 'register' ? 'bg-neutral-800 text-white shadow' : 'text-neutral-400 hover:text-white'}`}
            onClick={() => setMode('register')}
          >
            Sign Up
          </button>
        </div>

        {mode === 'login' ? (
          <form onSubmit={handleLoginSubmit} className="space-y-5">
            <Input label="Email address" type="email" value={loginEmail} onChange={(e: any) => setLoginEmail(e.target.value)} placeholder="shop@example.com" required />
            <Input label="Password" type="password" placeholder="••••••••" required />

            <div className="p-4 bg-[#0a0a0a] rounded-lg border border-neutral-800">
              <label className="text-xs font-bold text-[#22c55e] uppercase mb-2 block tracking-wider">Demo: Select Access Level</label>
              <select
                value={roleDemo}
                onChange={(e) => setRoleDemo(e.target.value as Role)}
                className="w-full p-2 rounded border border-neutral-700 bg-neutral-900 text-sm text-white focus:border-[#22c55e] outline-none"
              >
                <option value="CUSTOMER">Customer (Form Only)</option>
                <option value="ADMIN">Administrator (Dashboard)</option>
              </select>
            </div>

            <Button type="submit" className="w-full h-12 text-base font-bold">
              <LogIn className="h-5 w-5 mr-1" /> Sign In
            </Button>
          </form>
        ) : (
          <form onSubmit={handleRegisterSubmit} className="space-y-4">
            <Input label="Full Name" value={regName} onChange={(e: any) => setRegName(e.target.value)} placeholder="John Doe" required />
            <Input label="Email Address" type="email" value={regEmail} onChange={(e: any) => setRegEmail(e.target.value)} placeholder="shop@example.com" required />
            <Input label="Phone Number" type="tel" value={regPhone} onChange={(e: any) => setRegPhone(e.target.value)} placeholder="503-555-0199" required />
            <Input label="Shop / Center Name" value={regShop} onChange={(e: any) => setRegShop(e.target.value)} placeholder="Hillsboro Collision" required />
            <div className="grid grid-cols-2 gap-4">
              <Input label="Password" type="password" placeholder="••••••••" required />
              <Input label="Confirm Password" type="password" placeholder="••••••••" required />
            </div>
            <Button type="submit" className="w-full h-12 text-base font-bold mt-2">
              <UserPlus className="h-5 w-5 mr-1" /> Create Account
            </Button>
          </form>
        )}
      </Card>
    </div>
  );
};

export default AuthPage;
