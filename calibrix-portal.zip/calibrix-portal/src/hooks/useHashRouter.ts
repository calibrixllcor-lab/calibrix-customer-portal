import { useState, useEffect } from 'react';

/**
 * Minimal hash-based router — no server rewrites needed, so the built
 * app can be hosted on GitHub Pages or any static host as-is.
 */
export const useHashRouter = () => {
  const [path, setPath] = useState(window.location.hash.replace('#', '') || '/');

  useEffect(() => {
    const onHashChange = () => setPath(window.location.hash.replace('#', '') || '/');
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigate = (newPath: string) => {
    window.location.hash = newPath;
  };

  return { path, navigate };
};
