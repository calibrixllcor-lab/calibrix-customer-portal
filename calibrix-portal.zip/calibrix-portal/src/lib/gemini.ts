export const systemPromptAdvisor =
  'You are Calibrix-AI, a helpful, professional support agent for Calibrix LLC. Answer questions about ADAS calibration, scheduling, EV services, billing, and the ID3 reporting tool. Keep answers concise and professional.';

// Set VITE_GEMINI_API_KEY in a local .env file (see .env.example).
// Without a key the chat widget gracefully falls back to mock mode.
const apiKey = import.meta.env.VITE_GEMINI_API_KEY ?? '';

export const fetchGeminiChat = async (
  history: { role: string; parts: { text: string }[] }[],
  systemInstruction: string
): Promise<string> => {
  if (!apiKey) {
    return 'AI services are currently running in mock mode. Please configure API keys for live responses.';
  }
  const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=${apiKey}`;
  const payload = { contents: history, systemInstruction: { parts: [{ text: systemInstruction }] } };

  try {
    const res = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (data.candidates && data.candidates[0]) return data.candidates[0].content.parts[0].text;
    return "I'm currently unable to process your request. Please try again later.";
  } catch (e) {
    return 'Connection error. Please try again later.';
  }
};
