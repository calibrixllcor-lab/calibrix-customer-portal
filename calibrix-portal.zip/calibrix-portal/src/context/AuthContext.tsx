import { createContext } from 'react';
import type { Role, User } from '../types';

export interface AuthContextType {
  user: User | null;
  login: (email: string, role?: Role) => void;
  register: (userData: Partial<User>) => void;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextType>({
  user: null,
  login: () => {},
  register: () => {},
  logout: () => {},
});
