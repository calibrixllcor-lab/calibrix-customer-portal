import { Button } from '../components/ui';
import AIChatWidget from '../components/AIChatWidget';

const PublicLayout = ({ children, navigate }: any) => (
  <div className="min-h-screen bg-[#0a0a0a] text-neutral-100 font-sans flex flex-col">
    <nav className="bg-[#171717] border-b border-neutral-800/50 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center cursor-pointer" onClick={() => navigate('/')}>
            <div className="flex items-center justify-center h-8 w-8 rounded bg-[#22c55e] text-black font-extrabold text-xl mr-2">C</div>
            <span className="font-bold text-xl tracking-widest text-white">CALIBRIX</span>
          </div>
          <div className="hidden md:flex items-center space-x-8">
            <button onClick={() => navigate('/')} className="text-sm font-medium text-neutral-300 hover:text-[#22c55e] transition-colors">Home</button>
            <button onClick={() => navigate('/services')} className="text-sm font-medium text-neutral-300 hover:text-[#22c55e] transition-colors">Our Solutions</button>
            <Button onClick={() => navigate('/login')} variant="ghost" className="text-neutral-300 hover:text-white">Portal Login</Button>
            <Button onClick={() => navigate('/register')}>Sign Up</Button>
          </div>
        </div>
      </div>
    </nav>
    <main className="flex-grow flex flex-col">{children}</main>
    <footer className="bg-[#171717] border-t border-neutral-900 text-neutral-500 py-12 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm">
        <p className="mb-4 text-[#22c55e] font-semibold tracking-widest text-lg">CALIBRIX LLC</p>
        <p className="text-neutral-400 font-medium tracking-widest uppercase">Mobile ADAS</p>
        <p className="mt-4">Serving Hillsboro, OR & Surrounding Areas</p>
        <p className="mt-2">503-330-7097 | info@calibrixllc.com</p>
        <p className="mt-8 text-neutral-600">Copyright © 2026 Calibrix LLC</p>
      </div>
    </footer>
    <AIChatWidget />
  </div>
);

export default PublicLayout;
