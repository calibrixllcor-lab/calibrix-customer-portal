import { useState } from 'react';
import {
  Clock, FileText, CreditCard, Calculator, HelpCircle, Building,
  Cpu, Plus, Settings, LogOut, Menu, X,
} from 'lucide-react';
import { Button } from '../components/ui';
import AIChatWidget from '../components/AIChatWidget';

const PortalLayout = ({ children, user, logout, navigate, path }: any) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // CUSTOMER gets just the form. ADMIN gets the full dashboard suite.
  const navItems = {
    CUSTOMER: [{ name: 'New Work Request', path: '/portal', icon: Plus }],
    ADMIN: [
      { name: 'Work In Progress', path: '/portal', icon: Clock },
      { name: 'Manage Requests', path: '/portal/requests', icon: FileText },
      { name: 'Invoiced', path: '/portal/invoiced', icon: CreditCard },
      { name: 'ADAS Recs', path: '/portal/adas-recs', icon: Calculator },
      { name: 'Support', path: '/portal/support', icon: HelpCircle },
      { name: 'Manage Shop', path: '/portal/shop', icon: Building },
      { name: 'System Arch (Dev)', path: '/portal/system', icon: Cpu },
    ],
  };

  const items = navItems[user.role as keyof typeof navItems];

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex flex-col md:flex-row font-sans text-neutral-100">
      {/* Mobile Header */}
      <div className="md:hidden bg-[#171717] border-b border-neutral-800 p-4 flex justify-between items-center z-20">
        <div className="flex items-center text-white">
          <div className="h-6 w-6 rounded bg-[#22c55e] text-black font-bold flex items-center justify-center mr-2 text-xs">C</div>
          <span className="font-bold tracking-widest">CALIBRIX</span>
        </div>
        <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-neutral-300">
          {sidebarOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Sidebar */}
      <div
        className={`${sidebarOpen ? 'block' : 'hidden'} md:block w-full md:w-64 bg-[#171717] border-r border-neutral-800/50 fixed md:sticky top-0 h-screen overflow-y-auto z-10 flex flex-col transition-all duration-300`}
      >
        <div className="p-6 hidden md:flex items-center text-white cursor-pointer" onClick={() => navigate('/')}>
          <div className="h-8 w-8 rounded bg-[#22c55e] text-black font-extrabold flex items-center justify-center mr-3 text-lg">C</div>
          <span className="font-bold tracking-widest text-lg">CALIBRIX</span>
        </div>

        <div className="px-4 py-2 mt-4 md:mt-0 flex-grow">
          <div className="text-xs font-bold text-neutral-600 uppercase tracking-wider mb-3 px-3">
            {user.role === 'ADMIN' ? 'Admin Controls' : 'Client Portal'}
          </div>
          <nav className="space-y-1">
            {items.map((item) => {
              const Icon = item.icon;
              const isActive = path === item.path;
              return (
                <button
                  key={item.name}
                  onClick={() => {
                    navigate(item.path);
                    setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-colors ${
                    isActive ? 'bg-[#22c55e]/10 text-[#22c55e]' : 'text-neutral-400 hover:bg-neutral-800 hover:text-white'
                  }`}
                >
                  <Icon className={`mr-3 h-5 w-5 ${isActive ? 'text-[#22c55e]' : 'text-neutral-500'}`} />
                  {item.name}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-4 border-t border-neutral-800/50 bg-[#0a0a0a]">
          <div className="flex items-center mb-4 px-2">
            <div className="h-8 w-8 rounded-full bg-neutral-800 text-[#22c55e] flex items-center justify-center font-bold mr-3 border border-neutral-700">
              {user.name.charAt(0)}
            </div>
            <div className="overflow-hidden">
              <div className="text-sm font-medium text-white truncate">{user.name}</div>
              <div className="text-xs text-[#22c55e] truncate font-mono">{user.role}</div>
            </div>
          </div>
          <Button
            variant="ghost"
            className="w-full justify-start text-neutral-400 hover:text-red-400 hover:bg-red-500/10"
            onClick={() => {
              logout();
              navigate('/');
            }}
          >
            <LogOut className="h-4 w-4 mr-2" /> Sign Out
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto w-full">
        <div className="max-w-6xl mx-auto">{children}</div>
      </main>
      <AIChatWidget />
    </div>
  );
};

export default PortalLayout;

// Re-exported for convenience in placeholder pages
export { Settings };
