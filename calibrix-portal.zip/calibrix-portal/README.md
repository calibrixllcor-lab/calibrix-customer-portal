# Calibrix Portal

Mobile ADAS calibration portal for Calibrix LLC — customer work requests, admin WIP dashboard, ID3 recommendations, and an AI support widget.

## Tech Stack

- **React 18 + TypeScript + Vite**
- **Tailwind CSS** (green `#22c55e` / neutral-950/900 theme)
- **lucide-react** icons
- Hash-based routing → works on any static host (GitHub Pages, Netlify, Cloudflare Pages) with **no server rewrites**

## Project Structure

```
calibrix-portal/
├── index.html
├── package.json
├── vite.config.ts          # base: './' for sub-path hosting
├── tailwind.config.js
├── postcss.config.js
├── tsconfig.json
├── .env.example            # VITE_GEMINI_API_KEY
└── src/
    ├── main.tsx
    ├── App.tsx             # root: auth state + routing
    ├── index.css           # Tailwind directives + theme tokens
    ├── types.ts            # User, Role, WIP_Record
    ├── data/mock.ts        # mock users + WIP records
    ├── lib/gemini.ts       # Gemini chat client (mock fallback)
    ├── context/AuthContext.tsx
    ├── hooks/useHashRouter.ts
    ├── components/
    │   ├── ui.tsx          # Button, Card, Input, Select, Id3Badge
    │   └── AIChatWidget.tsx
    ├── layouts/
    │   ├── PublicLayout.tsx
    │   └── PortalLayout.tsx
    └── pages/
        ├── HomePage.tsx
        ├── AuthPage.tsx    # login + register
        ├── CustomerWorkRequestForm.tsx
        └── admin/
            ├── AdminWorkInProgress.tsx
            ├── AdminManageRequests.tsx
            ├── AdminADASRecs.tsx
            ├── AdminPlaceholder.tsx
            └── AdminSystemArch.tsx
```

## Getting Started

```bash
npm install
npm run dev        # local dev at http://localhost:5173
npm run build      # production build -> dist/
npm run preview    # preview the production build
```

### Optional: live AI chat

Copy `.env.example` to `.env` and add your Gemini API key:

```bash
cp .env.example .env
# VITE_GEMINI_API_KEY=your_key_here
```

Without a key, the chat widget runs in mock mode and returns a canned message.

## Deploy

Any static host works — build with `npm run build` and publish the `dist/` folder.

- **GitHub Pages**: push to GitHub, enable Pages from the `dist` output (e.g. via the `peaceiris/actions-gh-pages` action or `vite-plugin-gh-pages`). Relative `base: './'` already supports sub-path hosting.
- **Cloudflare Pages / Netlify / Vercel**: build command `npm run build`, output directory `dist`.

## Demo Access

Use any email on the sign-in screen and pick an access level:

- **Customer** → Work Request Form only
- **Administrator** → Full dashboard (WIP, Requests, Invoiced, ADAS Recs, Support, Shop, System Arch)
